package connectmodel;

public class Main 
{
	public static void main(String[] args)
    {
		Controller connect4 = new Controller();
		//connect4.start;
    }

}
