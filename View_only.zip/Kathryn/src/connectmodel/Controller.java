package connectmodel;

import connectmodel.View;

/**
 * 
 * 
 * @author Andrew Tompkins
 *
 */

public class Controller 
{

    public View myView;
	
	public Controller()
    {
        myView = new View(this);
        String firstName;
    	//firstName = JOptionPane.showInputDialog("First Name");
    }
    
	
}
